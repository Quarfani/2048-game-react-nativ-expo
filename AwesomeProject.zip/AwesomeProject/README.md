# Игра 2048 на React Native

Для запуска
```bash
npx expo install
```
```bash
npx expo start -c
```
